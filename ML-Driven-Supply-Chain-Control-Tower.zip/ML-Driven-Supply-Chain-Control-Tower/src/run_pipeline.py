"""Run and validate the reproducible supply-chain control-tower pipeline."""

import os
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

STEPS = [
    "src/baseline_forecasting.py",
    "src/sku_level_forecasting.py",
    "src/forecast_backtesting.py",
    "src/inventory_optimization.py",
    "src/supplier_risk.py",
    "src/temporal_disruption.py",
    "src/create_control_tower.py",
    "src/business_impact.py",
    "src/business_impact_simulation.py",
    "src/finance_analysis.py",
    "src/shap_explainability.py",
    "src/validate_outputs.py",
]


def main():
    for script in STEPS:
        print(f"\n{'=' * 72}\nRUNNING {script}\n{'=' * 72}")
        result = subprocess.run([sys.executable, script], check=False, cwd=ROOT)
        if result.returncode != 0:
            raise SystemExit(f"Pipeline stopped: {script} exited with code {result.returncode}")
    print("\nPipeline completed and outputs validated successfully.")


if __name__ == "__main__":
    main()
